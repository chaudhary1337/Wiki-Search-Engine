clear
python3 src/searcher.py /tmp/indices queries.txt
